---
id: add_aliyun_ds
title: 添加阿里云数据源
---
CloudCanal 支持自建数据源和云托管数据源，本文档简要介绍如何添加阿里云数据源到 CloudCanal 中。为了方便演示，本章节例子中添加的为阿里云 RDS for MySQL。

## 操作说明
### 准备阿里云子账号
参考[阿里云RAM访问控制](https://help.aliyun.com/product/28625.html?spm=5176.2020520153.help.dexternal.3820336anMrJ7b)
文档，创建一个提供给 CloudCanal 使用的用于访问和操作阿里云数据库的子账号并且生成对应的 AccessKey 和 SecretKey。一般而言，CloudCanal 添加阿里云数据源需要子账号具备的基本权限包括：

- 通过阿里云 OpenAPI 获取数据源列表。
- 通过阿里云 OpenAPI 添加数据源白名单权限。

### 配置阿里云OpenAPI调用使用的AccessKey和SecretKey
点击控制台右上角的用户设置，选择 **阿里云访问权限 **然后输入有数据源 OpenAPI 调用权限的 AccessKey 和 SecretKey。
如果用户不希望 CloudCanal 保存 AccessKey 和 SecretKey，用户在添加完毕数据源以后可以再次打开该窗口，解除授权访问来避免 CloudCanal 存储该授权信息。
![](../../assets/add_datasource/aliyun_rds/1.png)

### 新增数据源
点击控制台导航栏的** 数据源管理 **然后点击** 新增数据源 **按钮。
![](../../assets/add_datasource/aliyun_rds/2.png)
### 查询并选择数据源

- 选择 **阿里云** , **数据源类型** 和相应 **区域** 查询 RDS。
- 列表会展示子账号有权限查看的数据源列表。
- 勾选左侧需要添加的数据源到右侧，确认无误后点击确定。
> 注意：CloudCanal 区域和 Aliyun Region 的对应关系可以查看官方文档[区域对照表](../../reference/region_mapping.md)。

![](../../assets/add_datasource/aliyun_rds/3.png)
### 白名单自动添加

- 此步骤可以选择添加某一集群机器 ip 白名单加入到对应 RDS 中。
![](../../assets/add_datasource/aliyun_rds/4.png)
### 自动创建账号

- 选择是否自动添加供 CloudCanal 访问的账号，默认为读写权限的普通账号。
![](../../assets/add_datasource/aliyun_rds/5.png)
### 确定信息并添加

- 点击新增数据源后，可在数据源管理中看到**创建中**的数据源。
![](../../assets/add_datasource/aliyun_rds/6.png)

- **创建完毕** 表示任务已经添加到系统中。
![](../../assets/add_datasource/aliyun_rds/7.png)
