---
id: add_self_maintain_ds
title: 添加自建数据源
---

CloudCanal 支持 **自建数据源** 和 **云托管数据源**，本文档简要介绍如何添加 **自建数据源** 到 CloudCanal 中。

### 添加数据源
- 登录 CloudCanal 控制台，**数据源管理** > **新增数据源**
- 选择 **自建数据库** , 区域选择 **不限** 或根据实际情况选择(非强依赖属性)
  ![](../../assets/add_datasource/self_maintain/2.png)
- 点击 **新增数据源** 按钮进行添加
- 数据源 **创建状态** 为 **创建完成**
  ![](../../assets/add_datasource/self_maintain/3.png)
