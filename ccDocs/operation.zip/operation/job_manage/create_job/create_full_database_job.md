---
id: create_full_database_job
title: 全库同步任务
---
CloudCanal支持对全库进行同步，包括同步过程中新增的表及数据。本文将介绍如何创建一个全库同步任务，以本地开发机(Mac)同步本地 MySQL 到 MySQL 为示例。

## 操作说明
1. 点击 **创建任务** 进入任务创建页面。
2. 选择源端和目标端的数据源。
3. 在源端数据源下方勾选 **高级模式**，迁移模式选择 **全库同步**。
![../../../assets/create_data_job/create_all_db_1.png](../../../assets/create_data_job/create_all_db_1.png)
4. 点击下一步，选择 **增量同步**。
5. 点击下一步，进入 **表&action过滤** 页面，其中表不可选。可点击 **action过滤** 对整个库进行过滤。
![../../../assets/create_data_job/create_full_db_2.png](../../../assets/create_data_job/create_full_db_2.png)
6. 点击 **创建任务**， 完成全库同步任务的创建。
7. 全库同步任务默认进行结构迁移，会检查目标库缺少的表并自动进行结构迁移。
![../../../assets/create_data_job/create_full_db_3.png](../../../assets/create_data_job/create_full_db_3.png)
8. 点击 **库表映射：查看** 可查看订阅的所有库表信息。
![../../../assets/create_data_job/create_full_db_4.png](../../../assets/create_data_job/create_full_db_4.png)
9. 当任务处于数据同步阶段时，点击 **功能列表**>**修改订阅**，可进行加库或减库。
![../../../assets/create_data_job/create_full_db_5.png](../../../assets/create_data_job/create_full_db_5.png)
