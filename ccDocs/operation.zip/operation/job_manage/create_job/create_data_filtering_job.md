---
id: create_data_filtering_job
title: 数据过滤任务
---
CloudCanal支持对同步任务进行数据过滤，以应对不同的场景和需求。本文将介绍如何创建一个带有数据过滤的任务，以本地开发机(Mac)同步本地 MySQL 到 MySQL 为示例。

## 操作说明
1. 点击 **创建任务** 进入任务创建页面。
2. 选择源端和目标端的数据源。
3. 点击 **下一步** 进入功能配置页，进行任务配置。
4. 点击 **下一步** 进入表&action过滤页， 选择需要同步的表。
5. 点击 **下一步** 进入数据处理页。选择需要设置过滤条件的表，点击 **操作** > **数据过滤条件**。
![1.png](../../../assets/create_data_filtering_job/1.png)
6. 输入正确的where条件，填入 **where** 之后的内容即可。
![2.png](../../../assets/create_data_filtering_job/2.png)
7. 点击 **创建任务**， 数据过滤任务创建成功。
![3.png](../../../assets/create_data_filtering_job/3.png)
![4.png](../../../assets/create_data_filtering_job/4.png)
