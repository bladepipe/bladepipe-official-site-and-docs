---
id: create_period_verified_correction_job
title: 定时校验订正任务
---
CloudCanal支持创建定时的校验与订正任务，保障数据的准确性。创建任务后，CloudCanal会定时自动按照 **校验**->**订正** 的顺序对选择的库表进行校验以及异常和丢失数据的修复。

本文将介绍如何创建一个定时的数据校验与订正任务，以本地开发机(Mac)校验本地 MySQL 到 MySQL 为示例。

## 操作说明
### 创建任务
1. 点击 **创建任务** 进入创建任务流程。
2. 选择源端和目标端的数据源。
3. 任务类型选择 **校验与订正**，勾选 **开启周期性校验** 并选择周期，校验订正模式选择 **校验后订正**。
![1.png](../../../assets/create_period_verified_correction_job/1.png)
4. 选择需要校验的表。这里仅支持选择已存在的表。
![2.png](../../../assets/create_period_verified_correction_job/2.png)
5. 选择需要校验的列。可以对不需要校验的列进行裁剪。
![3.png](../../../assets/create_period_verified_correction_job/3.png)
6. 点击 **创建任务**，周期性校验与订正任务创建成功。
![4.png](../../../assets/create_period_verified_correction_job/4.png)
7. 周期性任务会显示下次执行的时间，到执行时间后会自动执行任务。如需立即执行任务，点击 **立即执行**， 任务将在2分钟后立即开始执行。
![5.png](../../../assets/create_period_verified_correction_job/5.png)
8. 校验任务完成后会自动进行订正。
![6.png](../../../assets/create_period_verified_correction_job/6.png)

### 查看校验历史和订正历史
1. 进行过至少一次校验和订正后，任务操作栏会出现 **校验历史** 和 **订正历史** 按钮。
2. 点击 **校验历史**，可以看到校验的历史，包括 **已校验行数**、**丢失行数** 和 **不一致行数**。
![7.png](../../../assets/create_period_verified_correction_job/7.png)
3. 点击 **订正历史**，可以看到校验的历史，包括 **总订正行数**、**订正丢失行数** 和 **订正不一致行数**。
![8.png](../../../assets/create_period_verified_correction_job/8.png)

### 查看校验结果
1. 进入任务详情页，点击 **查看日志**，可以看到diff.log文件。diff.log文件记录了校验过程中不一致和丢失的数据。
![9.png](../../../assets/create_period_verified_correction_job/9.png)
