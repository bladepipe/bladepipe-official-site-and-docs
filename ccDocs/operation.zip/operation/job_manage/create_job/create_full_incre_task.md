---
id: create_full_incre_task
title: 基础任务
---

CloudCanal支持创建全量增量的一体化任务，包含表结构迁移、全量数据初始化、数据实时同步等多个阶段。任务启动后，CloudCanal会自动按顺序执行任务中的多个阶段，整个过程完全自动化。增量实时同步阶段，任务通过启动位点的控制可以确保全量期间的增量也完整同步到对端。

本文将介绍如何创建一个带结构迁移、全量数据初始化和数据校验的数据同步任务，以本地开发机(Mac)迁移同步本地 MySQL 到 MySQL 为示例。

## 操作说明
### 功能入口

- 开始创建任务
![1.png](../../../assets/create_full_incre_task/1.png)

### 选择数据源

- 选择任务运行的 **绑定集群** ，如果所选有多个节点，CloudCanal 将会启动正常[两级容灾调度](../../../intro/product_arch.md)，如果只有单个节点，CloudCanal 只会有单级容灾调度。
![2.png](../../../assets/create_full_incre_task/2.png)
- 选择源端和目标端数据源，并分别 **测试数据源** ，选择数据库或 Schema 等信息 , CloudCanal 支持多 Schema 迁移同步。
![3.png](../../../assets/create_full_incre_task/3.png)

### 选择任务类型

- CloudCanal 支持数据迁移、数据同步、结构迁移、数据校验等多种任务类型。创建全量增量一体化任务，此处可以选择 **数据同步** 并勾选 **全量初始化**。
![4.png](../../../assets/create_full_incre_task/4.png)
- 规格和计费无关，在机器资源充足的情况下，可选大规格，性能好、稳定性高。任务较多时，考虑到机器利用率，可配置具备特定数据特征的规格。
- 默认选择创建后 **自动启动**，可选择创建后暂不启动。

### 选择数据表

- 选择表名映射，选择特定操作过滤。
![5.png](../../../assets/create_full_incre_task/5.png)
- 支持在搜索框中按条件搜索表
![6.png](../../../assets/create_full_incre_task/6.png)

### 选择列

- 选择迁移列，也可设定**按条件过滤迁移同步的数据**。
![7.png](../../../assets/create_full_incre_task/7.png#border-shadow)

### 创建确认

- 确认任务内容的选择，默认任务创建后自动启动。
![8.png](../../../assets/create_full_incre_task/8.png)

### 创建成功

- 创建后如果为自动启动任务，任务会自动启动。成功创建全量、增量一体化任务并启动后，任务会自动完成结构迁移、全量初始化、增量同步。
![9.png](../../../assets/create_full_incre_task/10.png)

- 进入任务详情查看具体任务运行信息
![10.png](../../../assets/create_full_incre_task/10.png)
![11.png](../../../assets/create_full_incre_task/11.png)
![12.png](../../../assets/create_full_incre_task/12.png)
