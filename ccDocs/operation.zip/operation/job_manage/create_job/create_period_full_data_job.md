---
id: create_period_full_data_job
title: 定时全量任务
---

CloudCanal支持定时全量任务，以应对各种需要使用ETL的场景。本文将介绍如何创建一个定时全量任务，以本地开发机(Mac)同步本地 MySQL 到 MySQL 为示例。

## 操作说明
1. 点击 **创建任务** 进入任务创建页面。s
2. 选择源端和目标端的数据源。
3. 选择 **全量迁移**， 勾选 **定时迁移**， 选择定时周期。此处 **不要勾选增量同步**。
![1.png](../../../assets/create_period_full_data_job/1.png)
4. 选择要同步的表及腰同步的列。
5. 点击 **创建任务**， 定时全量任务创建成功。定时全量任务会展示下次执行的时间，等到该时间系统会自动开始执行该任务。
![2.png](../../../assets/create_period_full_data_job/2.png)
6. 如想立即执行任务，点击 **立即执行**， 任务将在两分钟后立即开始执行。
![3.png](../../../assets/create_period_full_data_job/3.png)
