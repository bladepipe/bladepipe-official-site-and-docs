---
id: log_in_customer_code
title: 自定义代码中打日志
description: 在自定义代码功能中，CloudCanal 提供了一个 logger 给到业务打印相关信息，以便排查问题
---
在自定义代码功能中，CloudCanal 提供了一个 logger 给到业务打印相关信息，以便排查问题。

## 操作步骤
1. 自定义代码中加入如下 logger,代码中即可使用并打印。
   ```
   protected static final Logger customLogger = LoggerFactory.getLogger("custom_processor");
   ```
  ![Log Error](../../../assets/create_process_job/log_error.png)
2. 启动任务并运行。
3. 找到日志文件并查阅内容。

## 示例
- 如`canal893h8v5f3j5`任务，全量和增量任务自定义代码日志路径如下
   ```
   //docker sidcar 容器或 tgz sidecar 节点
   /home/clougence/logs/cloudcanal/tasks/canal893h8v5f3j5_FULL/custom_process.log
   /home/clougence/logs/cloudcanal/tasks/canal893h8v5f3j5_INCREMENT/custom_process.log
   ```
- 可在控制台( **任务详情 > 查看日志 > custom_process.log** )看到日志内容
  ![Console Customer Log](../../../assets/create_process_job/console_customer_log.png)

- 也可以到 **任务日志目录** 查看完整的日志文件
  ![File Customer Log](../../../assets/create_process_job/file_customer_log.png)

