---
id: debug_customer_code
title: 自定义代码Debug
description: 如果你是一名 java 开发同学，使用 CloudCanal 自定义代码碰到问题，可以打开 CloudCanal debug 模式，任务启动将自动等待 debug 链接。
---
如果你是一名 java 开发同学，使用 CloudCanal 自定义代码碰到问题，可以打开 CloudCanal debug 模式，任务启动将自动等待 debug 链接。

## 操作步骤
1. 打开 **任务详情** > **功能列表** > **参数设置**。
![Job Parameter Set](../../../assets/create_process_job/job_param_set.png)
2. 调整 **debugMode** 参数，设置为 **true**。
3. 调整 **debugPort**。
   - docker 部署: 18787 端口
   - tgz 部署: 8787 端口 
4. 生效配置并重启任务。任务启动后将会停止并等待远程 debug 客户端连接。
![Change Code Debug](../../../assets/create_process_job/change_debug_config.png)
5. 远程 debug ,以 idea 为例，设置任务运行地址。
6. Host 为 sidecar 容器或运行节点 ip , Port 为 18787/8787 端口）。
![Debug Code Config](../../../assets/create_process_job/debug_code_config.png)
