---
id: create_similar_job
title: 创建相似任务
---

在一些场景下，用户创建一个迁移同步任务需要勾选和配置的表是十分复杂的。CloudCanal提供了创建相似任务的功能，允许用户基于过去已经创建任务的配置快速创建一条配置、订阅关系接近的链路，可以大大提升用户创建任务的效率。

## 操作说明

在任务详情页点击 **功能列表**->**创建相似任务** 

![image.png](../../../assets/create_similar_job/1.png)

CloudCanal会读取该任务的配置，在创建新任务过程中自动填充配置。用户可以在自动填充的配置上稍作调整即可完成相似任务的创建。

![advanced_setting8.png](../../../assets/create_similar_job/2.png)
