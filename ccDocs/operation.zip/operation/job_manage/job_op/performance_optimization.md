---
id: performance_optimization
title: 性能调优
description: 本文介绍如何对CloudCanal任务进行性能调优。
---
任务采用默认配置时，如果出现某些大字段导致性能上不去或者出现 OOM 的情况，一般可以按照如下方式确认性能瓶颈原因并且进行调优。

## 确认性能瓶颈原因
### 1. 程序是否异常
首先查看监控管理，查看有没有近期的任务异常，如果对应任务有写入异常，可能一些表的数据就会一直无法写入。
> Tips: 异常监控处请选择任务异常，右侧点击查看异常堆栈<br />![异常堆栈](../../../assets/task_and_performance/3.png)

### 2. 程序是否存在GC问题导致的OOM
**任务监控** 的 **资源监控** 页面可以查看 GC 情况，如果存在 FGC 的耗时突显和 FGC 数量大于 0（正常情况下应该为 0），则说明任务运行时 Java 的垃圾回收导致性能降低和 OOM。<br />![GC 图表](../../../assets/task_and_performance/4.png)

### 3. 存在GC问题时
#### 3.1 全量迁移参数修改
**任务详情**->**参数设置**，改小 **fullRingBufferSize** 参数、**fullBatchSize** 参数、**writeParallel** 参数的值，然后观察 FGC 相关指标是否变小。<br />如果没有 GC 问题，需要提升性能，也可以适当增大以上参数，提升并行和批处理效率<br />
![fullRingBufferSize](../../../assets/task_and_performance/5.png)
![fullBatchSize](../../../assets/task_and_performance/6.png)
![writeParallel](../../../assets/task_and_performance/7.png)

#### 3.2 增量同步参数修改
**任务详情**->**参数修改**，改小 **increRingBufferSize** 参数、**increBatchSize** 参数、**writeParallel** 参数的值，然后观察 FGC 相关指标是否变小。

### 4. 不存在GC问题
适当增大第三步涉及的参数，提升 **并行** 和 **批处理** 效率。
![increBatchSize](../../../assets/task_and_performance/8.png)
![writeParallel](../../../assets/task_and_performance/7.png)
> Tips: 任务的负载不同、环境不同，最佳的参数配置也有所不同，用户可以自行验证，找到自家最佳的参数配置组合，一切请以实际情况为准。

### 5. 对端写入瓶颈确认
**任务详情**->**查看日志**。其中最后一列是耗时的毫秒数。

**日志路径**: /home/clougence/logs/cloudcanal/tasks/${taskName}/apply_commit.log
![writeParallel](../../../assets/task_and_performance/9.png)
例如上面一批的耗时为将近 10s，说明对端处理能力存在瓶颈。在不存在 FGC 的前提下，可以尝试增大并行数，以及前文提到的 3 个批量相关的参数

### 6. 机器资源状况确认
确认机器的 **cpu usage**，**cpu load **等情况，如果以上源对端不存在瓶颈，并且也不存在 OOM 和异常，可以查看机器的监控，如果监控发现机器负载比较高，则考虑使用更高规格的机器。

### 7. 规格调整
如果上诉检查都没问题，且资源富余，建议考虑修改规格。

CloudCanal 规格以任务进程的最大内存占用表示。一个规格 id 分别体现了全量迁移、增量同步、数据校验进程的内存最大占用量。<br />目前可供修改的规格 id 主要描述增量任务内存占用，以下步骤描述如何修改增量任务的规格。

#### 步骤
1. 任务详情 > 参数修改。 ![参数修改](../../../assets/task_and_performance/1.png)
2. 搜索 **specId** 参数，选择合适的规格 id 进行修改。 ![规格修改](../../../assets/task_and_performance/2.png)
3. 如果任务在运行中，将自动重启。
