---
id: alarm_conf
title: 配置告警
description: 本文档介绍 CloudCanal docker 部署如何配置告警。CloudCanal目前支持钉钉告警和微信告警2种模式。
---
本文档介绍 CloudCanal docker 部署如何配置告警。

CloudCanal任务告警、机器告警均需要先完成系统的告警配置才可以正常工作。告警当前支持的发送方式和对接实现方式主要如下表所示：

| 发送方式       | 对接实现方式  |
|------------|---------|
| 短信         | 阿里云短信服务 |
| 即时通讯软件(IM) | 钉钉      |
| 即时通讯软件(IM) | 微信      |
| 即时通讯软件(IM) | 飞书      |
| 即时通讯软件(IM) | webhook |


## 配置告警
### 告警设置准备

- 创建钉钉告警群，创建钉钉机器人，获取告警API参考[《创建告警机器人》](../../productOP/dailyOP/create_dingding_group)
- 创建微信告警群，获取告警API参考[《使用企业微信群接收告警通知》](https://cloud.tencent.com/document/product/248/50413)
- 创建飞书机器人，参考[《自定义机器人指南》](https://open.feishu.cn/document/ukTMukTMukTM/ucTM5YjL3ETO24yNxkjN)
- 自定义webhook请自行准备好webhook

### 操作步骤
1. 点击控制台右上角头像，选择 **账户信息**。
2. 修改账号信息页的 **用户设置**。如果是从未配置过的，显示为红色待创建状态。
![image.png](../../assets/alarm_conf/image.png)
3. 根据需要配置相关参数，参数说明如下：
   - **alertImType**：设置告警类型，目前支持钉钉、企业微信、飞书三种即时通讯工具，也可以设置自定义告警机器人。
   - **defaultImAlertUrl**：配置发送普通告警的webhook。
   - **criticalImAlertUrl**：配置发送重要告警的webhook。
   - **taskAlertInhibitMin**：配置告警抑制间隔，针对同一个任务的异常或者延迟，或相同告警内容，间隔多久告警一次，单位为分钟，默认为1分钟。
4. 配置后即可生效。

> Tips：该告警配置作用于当前用户，请在注册新账号后及时进行配置。

