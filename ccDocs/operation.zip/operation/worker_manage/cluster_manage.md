---
id: cluster_manage
title: 集群管理
---
集群是CloudCanal中的一个逻辑概念，用于将机器进行分组。用户可以根据业务属性、地域等信息将机器分别划分成不同的机器集群。

## 创建集群

点击 **新增集群**，填好描述地域等信息即可创建成功。地域对照信息请查看[区域对照表](../../reference/region_mapping.md)。
![新增集群](../../assets/worker_manage/cluster_manage1.png)

## 删除集群
删除集群前请确认集群内的机器都已删除，否则无法删除集群。
