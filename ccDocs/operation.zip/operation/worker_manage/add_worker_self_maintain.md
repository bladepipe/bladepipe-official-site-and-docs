---
id: add_worker_self_maintain
title: 添加机器
---
CloudCanal允许用户添加自建机器。Docker版本添加自建机器的流程请参考 [添加机器与高可用部署](../../productOP/systemDeploy/ha_install)。商业用户tgz版本请联系CloudCanal管理员。
