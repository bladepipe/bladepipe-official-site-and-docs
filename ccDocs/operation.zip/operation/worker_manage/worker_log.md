---
id: worker_log
title: 查看在线机器日志
---
CloudCanal提供了在线查看日志的能力。通过查看在线日志，用户可以了解当前机器运行的情况。

## 操作说明
### 查看机器日志
点击 机器管理->选择机器，然后点击右侧 **查看机器日志**，我们可以查看机器的几个重要日志文件：

- sidecar.log: 机器的主要运行日志信息均在该日志中。
- console_rs_info.log: 机器会与控制台和任务进程进行网络通信，该日志记录通信请求。
- console_rs_error.log: 机器通信的异常信息会记录在该日志。
- console_rs_slow.log: 机器的慢通信日志会记录在该日志文件。

![](../../assets/worker_log/1.png)

> TIPS: 在线日志只提供近期的日志信息。如果是请求CloudCanal工作人员排查问题请提供完整的机器日志。完整的机器日志可以在机器路径：/home/clougence/logs/cloudcanal/sidecar下获取

